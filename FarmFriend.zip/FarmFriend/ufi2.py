import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageTk
import os

# Function to suggest a crop based on inputs
def suggest_crop():
    soil_type = soil_type_var.get()
    region = region_var.get()
    previous_crop = prev_crop_var.get()

    if not soil_type or not region or not previous_crop:
        messagebox.showwarning("Input Error", "Please fill all fields.")
        return

    suggestion = ""
    report = ""

    # Basic suggestion logic (can be expanded)
    if soil_type == "Loamy" and region == "Tropical":
        if previous_crop == "Wheat":
            suggestion = "Rice"
            report = "Rice is suitable after Wheat in loamy soil under tropical climate."
        else:
            suggestion = "Sugarcane"
            report = "Loamy soil in tropical regions is ideal for sugarcane."
    elif soil_type == "Sandy" and region == "Temperate":
        suggestion = "Barley"
        report = "Barley grows well in sandy soil and temperate regions."
    else:
        suggestion = "Soybean"
        report = "Soybean is a versatile crop suitable for diverse conditions."

    if suggestion:
        messagebox.showinfo("Crop Suggestion", f"Suggested Crop: {suggestion}\n\nReason: {report}")
    else:
        messagebox.showwarning("No Suggestion", "Unable to provide a suggestion based on the given inputs.")

# Function to load images from a folder and create a slideshow
def load_images():
    image_folder = r"C:\Users\tejat\OneDrive\Desktop\Koushik\Koushik\Hacked\UnifiedApp\Farm Friend"  # Replace with the actual folder path
    images = []
    
    if not os.path.exists(image_folder):
        messagebox.showerror("Error", "Image folder not found")
        return []
    
    for file in os.listdir(image_folder):
        if file.endswith(('png', 'jpg', 'jpeg')):
            img = Image.open(os.path.join(image_folder, file))
            img = img.resize((1920, 1080), Image.LANCZOS)  # Resize the image to 16:9 (full screen)
            images.append(ImageTk.PhotoImage(img))
    if not images:
        messagebox.showerror("Error", "No valid images found in the folder")
    return images

# Function to cycle through images for the slideshow
def update_background_image(image_list, label, index=0):
    if image_list:
        label.config(image=image_list[index])
        index = (index + 1) % len(image_list)  # Loop through the images
        root.after(3000, update_background_image, image_list, label, index)  # Change image every 3 seconds

# Create the GUI
root = tk.Tk()
root.title("Crop Suggestion System")
root.state('zoomed')  # Open in full-screen window

# Load images and start the slideshow
image_list = load_images()

if image_list:  # Only start if images are loaded
    background_label = tk.Label(root)
    background_label.place(x=0, y=0, relwidth=1, relheight=1)
    update_background_image(image_list, background_label)

# Add the title at the top of the window with place to ensure it's always visible on top
title_label = tk.Label(root, text="Unified Farmer Interface", font=("Arial", 24, "bold"), bg="lightgreen", fg="black", pady=10)
title_label.place(relx=0.5, y=10, anchor="n")  # Centered at the top, fixed y position

# Create frames for input with transparent background
input_frame = tk.Frame(root, bg='white', padx=10, pady=10, relief=tk.RIDGE, bd=5)
input_frame.place(relx=0.5, rely=0.5, anchor=tk.CENTER)  # Center the frame

# Labels and Input Fields with dynamic fonts for better visibility
tk.Label(input_frame, text="Soil Type:", font=("Arial", 14), bg="white").grid(row=0, column=0, sticky="w", pady=5)
tk.Label(input_frame, text="Region:", font=("Arial", 14), bg="white").grid(row=1, column=0, sticky="w", pady=5)
tk.Label(input_frame, text="Previous Crop:", font=("Arial", 14), bg="white").grid(row=2, column=0, sticky="w", pady=5)

soil_type_var = tk.StringVar()
region_var = tk.StringVar()
prev_crop_var = tk.StringVar()

soil_types = ["Loamy", "Sandy", "Clay", "Silty"]
regions = ["Tropical", "Temperate", "Subtropical", "Arid"]
previous_crops = ["Wheat", "Rice", "Maize", "None"]

tk.OptionMenu(input_frame, soil_type_var, *soil_types).grid(row=0, column=1, pady=5, padx=10)
tk.OptionMenu(input_frame, region_var, *regions).grid(row=1, column=1, pady=5, padx=10)
tk.OptionMenu(input_frame, prev_crop_var, *previous_crops).grid(row=2, column=1, pady=5, padx=10)

# Suggest Crop Button with custom styling
suggest_button = tk.Button(input_frame, text="Suggest Crop", font=("Arial", 14, "bold"), bg="lightblue", fg="black", padx=10, pady=5, command=suggest_crop)
suggest_button.grid(row=3, column=0, columnspan=2, pady=20)

# Start the GUI
root.mainloop()
